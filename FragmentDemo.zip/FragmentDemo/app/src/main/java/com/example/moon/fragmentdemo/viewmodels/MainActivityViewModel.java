package com.example.moon.fragmentdemo.viewmodels;

import android.arch.lifecycle.ViewModel;

public class MainActivityViewModel extends ViewModel {

}
